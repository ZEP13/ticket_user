package zela.ticket.dto;

public record UserDTO(Long id, String nom, String password) {
}
